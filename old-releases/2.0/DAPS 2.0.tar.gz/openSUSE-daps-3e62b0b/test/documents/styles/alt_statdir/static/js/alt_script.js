var foo = bar;
